package Calculator;
public class Add extends Calc{
	public int add(int a,int b) {
		return(a+b);
	}
}
