package Calculator;

public class Multi extends Calc{

	public Multi() {
		// TODO Auto-generated constructor stub
	}
	public int multi(int a,int b) {
		return (a*b);
	}
}
