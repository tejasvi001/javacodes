package Calculator;

public class Sub extends Calc {

	public Sub() {
		// TODO Auto-generated constructor stub
		super();
	}
	public int sub(int a,int b) {
		return(a-b);
	}
}
