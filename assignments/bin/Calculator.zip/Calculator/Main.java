package Calculator;

public class Main {

	public static void main(String args[]) {
		// TODO Auto-generated constructor stub
		Calculator obj=new Calculator();
	}

}
