package Calculator;

public class Divide extends Calc {

	public Divide() {
		// TODO Auto-generated constructor stub
		super();
	}
	public int divide(int a,int b) {
		return (a/b);
	}
}

