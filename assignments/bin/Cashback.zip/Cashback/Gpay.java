package Cashback;

public interface Gpay {
	int GPAY=0;
	int getgpay();
	void setgpay(int p);
}
