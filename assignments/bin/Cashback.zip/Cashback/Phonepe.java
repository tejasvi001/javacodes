package Cashback;

public interface Phonepe {
	int PHONEPE=0;
	int getphonepe();
	void setphonepe(int p);
}
