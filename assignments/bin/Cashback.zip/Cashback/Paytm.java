package Cashback;

public interface Paytm {
	
	int x = 0;
	int getpaytm();
	void setpaytm(int p) ;
}
